/*
 * $Id: sarpack.h,v 1.1 2002/07/29 05:24:39 go Exp $
 */


#ifndef __SARPACK_H
#define __SARPACK_H

typedef struct {

	u_char *addr;      /* $B@hF,%"%I%l%9(B         */
	size_t size;       /* $B%5%$%:(B               */
	int file_num;      /* $B%Q%C%/Cf$N%U%!%$%k?t(B */

	struct FileInfo {
		char *name;    /* $B%U%!%$%kL>(B                   */
		off_t pos;     /* $B%U%!%$%k@hF,$+$i$N%*%U%;%C%H(B */
		size_t len;    /* $B%U%!%$%k$N%5%$%:(B             */
	} *files;

} SarPack;

extern SarPack *sarpack_new(const char *packname);
extern void     sarpack_delete(SarPack *);

extern int sarpack_find(SarPack *p, const char *name);
extern u_char *sarpack_extract(SarPack *p, int index, size_t *sizeret);

#endif







