
#include "inc.h"

#include "minix.h"
#include "iwram_arm.h"
#include "div_arm.h"
#include "gbfs.h"
#include "lib.h"
#include "ad_arm.h"

#include "main.h"
#include "screen.h"
#include "sizuku.h"
#include "script.h"

//---------------------------------------------------------------------------
ST_SCRIPT  Script;
ST_HISTORY History;

//---------------------------------------------------------------------------
EWRAM_CODE void ScriptInit()
{
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptLoadScenario(u16 scn, u16 blk)
{
	char buf[64];
	_Sprintf(buf, SIZUKU_SCN_STR, scn);

	u8* pScn = GBFSGetFilePointer(buf);

	if(pScn == NULL)
	{
		ErrorMessage("scn not found.", NULL);
	}
//	TRACEOUT("pScn = %x\n", pScn);

	ScriptLoad(pScn, scn, blk);
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptLoad(u8* pScn, u16 scnNo, u16 blk)
{
	ST_SCRIPT_HEADER* h = (ST_SCRIPT_HEADER*)pScn;
	ST_SCRIPT*        s = &Script;

	s->pScn    = pScn + h->scnOffset;
	s->pTxt    = pScn + h->txtOffset;
	s->scnNo   = scnNo;
	s->scnSize = h->scnSize;
	s->txtSize = h->txtSize;

	s->pScnCurHead = s->pScn + GET_SHORT(s->pScn + (blk+1) * 2);
	s->pScnCur     = s->pScnCurHead;
	s->pTxtCur     = NULL;

//	TRACEOUT("s->pScnCur = %x\n", s->pScnCur);
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptExec()
{
	ScriptParserScn();
}
//---------------------------------------------------------------------------
//�u���v�V�i���I�p�[�T�{��
#define c s->pScnCur

EWRAM_CODE void ScriptParserScn()
{
	ST_SCRIPT* s = &Script;

	for(;;)
	{
//		ScriptDebugScn(s->scnNo);

		switch(c[0])
		{
		case 0x00:
			TRACEOUT("[�u���b�N�I��]\n");
			c++;
			return;

		case 0x01:				//�������
			switch(c[1])
			{
				case 0x01:
					TRACEOUT("[���ɂ�聨��]-[���b�Z�[�W: %d]\n", c[2]);
					ScriptParserTxt(c[2], TRUE);
					ScreenFontDrawCls();
					c += 3;
					break;

				case 0x02:
					TRACEOUT("[�Á����ɂ��]-[���b�Z�[�W: %d]\n", c[2]);
					ScriptParserTxt(c[2], TRUE);
					ScreenFontDrawCls();
					c += 3;
					break;

				case 0x03:
					TRACEOUT("[�܂̎�: %02x]\n", c[2]);
					c += 3;
					break;

				case 0x04:
					TRACEOUT("[���ɂ��2(�َ���)]-[���b�Z�[�W:%d]\n", c[2]);
					ScriptParserTxt(c[2], TRUE);
					ScreenFontDrawCls();
					c += 3;
					break;

				default:
					TRACEOUT("�ُ��0x01�R�}���h�ł�(%02x,%02x)\n", c[1], c[2]);
					return;
			}
			break;

		case 0x03:
			TRACEOUT("[��: %02x]\n", c[0]);
			c += 2;
			break;

		case 0x04:
			TRACEOUT("[�W�����v: SCN%03d.dat Block %d]\n", c[1], c[2]);
			ScriptLoadScenario(c[1], c[2]);
			break;

		case 0x05:
			TRACEOUT("[�I����: %d][���b�Z�[�W: %d]\n", c[2], c[1]);
			c = ScriptWaitSelect(c);
			break;

		case 0x06:
			TRACEOUT("[��: %02x]\n", c[0]);
			c++;
			break;

		case 0x07:
			TRACEOUT("[�O�̑I�����ɖ߂�}�[�N�ʒu]\n");
			c++;
			break;

		case 0x0a:
			TRACEOUT("[�w�i���[�h: MAX_S%02d.img]\n", c[1]);
			c += 2;
			break;

		case 0x14:
			TRACEOUT("[��ʃN���A? %02d]\n", c[1]);
			c += 2;
			break;

		case 0x16:
			TRACEOUT("[H�V�[�����[�h: MAX_H%02d.img]\n", c[1]);
			c += 2;
			break;

		case 0x22:
			TRACEOUT("[�L�����N�^���[�h: MAX_C%02x.LFG %02x]\n", c[1], c[2]);
			c += 3;
			break;

		case 0x24:
			TRACEOUT("[�L�����N�^���[�h2?(center?): MAX_C%02x.LFG]\n", c[1]);
			c += 3;
			break;

		case 0x28:
			TRACEOUT("[�I�����̑O�ɑ��݂���f�[�^]\n");
			c++;
			break;

		case 0x38:
			TRACEOUT("[�\\������: %02x]\n", c[1]);
			c += 2;
			break;

		case 0x3d:
			TRACEOUT("[if�� flg:%02x == 0x%02x pc += %02x]\n", c[1], c[2], c[3]);
			if( SizukuGetSysFlag(c[1]) == c[2] )
			{
				c += c[3];
			}
			c += 4;
			break;

		case 0x3e:
			TRACEOUT("[if��(�ے�) flg:%02x != 0x%02x pc += %02x]\n", c[1], c[2], c[3]);
			if( SizukuGetSysFlag(c[1]) != c[2] )
			{
				c += c[3];
			}
			c += 4;
			break;

		case 0x47:
			TRACEOUT("[�t���O�̒l�ݒ�: %02x = 0x%02x]\n", c[1], c[2]);
			SizukuSetSysFlag(c[1], c[2]);
			c += 3;
			break;

		case 0x48:
			TRACEOUT("[�t���O���Z: %02x += 0x%02x\n", c[1], c[2]);
			SizukuAddSysFlag(c[1], c[2]);
			c += 3;
			break;

		case 0x54:
			TRACEOUT("[�e�L�X�g���b�Z�[�W: %d]\n", c[1]);
			ScriptParserTxt(c[1], TRUE);
			ScreenFontDrawCls();
			c += 2;
			break;

		case 0x5a:
			TRACEOUT("[��: %02x]\n", c[0]);
			c++;
			break;

		case 0x5c:
			TRACEOUT("[��: %02x %02x]\n", c[0], c[1]);
			c += 2;
			break;

		case 0x61:
			TRACEOUT("[��: %02x %02x %02x]\n", c[0], c[1], c[2]);
			c += 3;
			break;

		case 0x62:
			TRACEOUT("[��:%02x(%02x)]\n", c[0], c[1]);
			c += 2;
			break;

		case 0x60:
		case 0x63:
		case 0x64:
		case 0x65:
		case 0x66:
			TRACEOUT("[��: %02x]\n", c[0]);
			c++;
			break;

		case 0x6e:
			TRACEOUT("[BGM�Đ�: %02x]\n", c[1]);
			ScriptMusicStart(SizukuGetBgmNo(c[1]), TRUE);
			c += 2;
			break;

		case 0x6f:
		case 0x73:
			TRACEOUT("[��: %02x]\n", c[0]);
			break;

		case 0x7e:
			TRACEOUT("[�G���f�B���O�ԍ��ݒ�: %02x]\n");
			/*
			 0 12 ���Ǝ�
			 1 12 ���� BAD
			 2 12 �j��
			 3 12 �g�[�X�^�[
			 4 11 ���D HAPPY
			 5 12 ���D BAD
			 6 11 ���� HAPPY
			 7 12 ���� BAD
			 8 10 True
			 9 11 �ڗ��q HAPPY
			 a 01 ��c����
			 b 14 �َ���
			 c 12 �َ��� BAD
			*/

			//�ڗ��q HAPPY �����Ă��邩�`�F�b�N�����܂�
			if( SizukuGetSysFlag(0x46) == 1)
			{
				SizukuSetSysFlag(0, 3);
			}
			else
			{
				if( SizukuGetSysFlag(0) == 0 )
				{
					SizukuSetSysFlag(0, 2);
				}
				else
				{
					SizukuSetSysFlag(0, 1);
				}
			}
			c += 2;
			break;

		case 0x7c:
			TRACEOUT("[�G���f�B���O�֌W ��:%02x()]\n", c[0]);
			c++;
			break;

		case 0x7d:
			TRACEOUT("[�G���f�B���OBGM�ݒ� & �N��:%02x %d]\n", c[0], c[1]);
//			ScriptMusicStartLoop(SizukuGetBgmNo(c[1]), FALSE);
			c += 2;
			break;

		case 0xff:
			TRACEOUT("[�{���A�N�Z�X�����Ȃ��ꏊ�ɃA�N�Z�X���� %02x]\n", c[0]);
			for(;;){}
			break;

		default:
			TRACEOUT("[ScriptParserScn unknown = %02x][no: %02x]\n", c[0], s->scnNo);
			for(;;){}
			break;

		} // switch(c[0])
	} // for(;;)
}
#undef c
//---------------------------------------------------------------------------
//�u���v�e�L�X�g�p�[�T�{��
#define c s->pTxtCur

EWRAM_CODE void ScriptParserTxt(u8 no, bool isHistoryAdd)
{
	ST_SCRIPT* s = &Script;
	u8  c1, c2, c3, c4;

	//�V�i���I�f�[�^�̃��[�h
	c = s->pTxt + GET_SHORT(s->pTxt + (no+1) * 2);
//	ScriptDebugTxt(no);

	//�����ɓo�^���邩�`�F�b�N�����܂�
	if(isHistoryAdd == TRUE)
	{
		HistoryAdd(c);
	}


	for(;;)
	{
		if(c[0] & 0x80 || c[0] == 'r')
		{
			c = ScriptDrawCode(c);
			continue;
		}

//		TRACEOUT("ScriptParserTxt = %c\n", c[0]);

		switch(c[0])
		{
			case '$':
				TRACEOUT("[���b�Z�[�W�I��]\n");
				c++;
				return;
#if 0
			//���@�O�����Ɉړ����܂����B

			case 'r':
				TRACEOUT("[���s]\n");
				c++;
				break;
#endif
			case 'p':
				TRACEOUT("[�y�[�W�X�V�҂�]\n");
				ScriptWaitPage();
				c++;
				break;

			case 'k':
			case 'K':
				TRACEOUT("[�L�[���͑҂�]\n");
				ScriptWaitKey();
				c++;
				break;

			case '0':
				TRACEOUT("[��: %02x]\n", c[0]);
				c++;
				break;

			case 'C':
				TRACEOUT("[�L�����N�^����: %c, MAX_C%c%c]\n", c[1], c[2], c[3]);
				c += 4;
				break;

			case 'B':
				TRACEOUT("[�w�i���[�h: %c%c, %d, %d]\n", c[1], c[2], Dig(c[3],c[4]), Dig(c[5],c[6]));
				c += 7;
				break;

			case 'S':
				TRACEOUT("[�w�i�t���L�����\\��: %c, MAX_C%c%c, MAX_S%c%c, %d, %d]\n", c[1], c[2],c[3],c[4],c[5], Dig(c[6],c[7]), Dig(c[8], c[9]));
				c += 10;
				break;

			case 'D':
				TRACEOUT("[�L�����S������\\��: %c, MAX_C%c%c]\n", c[1], c[2], c[3]);
				c += 4;
				break;

			case 'A':
			case 'a':
				TRACEOUT("[�L����3�l�\\��: %c, %c%c, %c, %c%c, %c, %c%c]\n", c[1],c[2],c[3],  c[4],c[5],c[6], c[7],c[8],c[9]);
				c += 10;
				break;

			case 'Q':
				TRACEOUT("[��ʂ�h�炷: %02x]\n", c[0]);
				c++;
				break;

			case 'E':
				TRACEOUT("[�w�i���[�h(2)?: MAX_S%c%c.LFG, %d, %d]\n", c[1], c[2], Dig(c[3], c[4]), Dig(c[5], c[6]));
				c += 7;
				break;

			case 'F':
				TRACEOUT("[�t���b�V��: %c]\n", c[0]);
				c++;
				break;

			case 'V':
				TRACEOUT("[�r�W���A��: VIS%c%c, %d, %d]\n", c[1], c[2], Dig(c[3], c[4]), Dig(c[5], c[6]));
				c += 7;
				break;

			case 'H':
				TRACEOUT("[H�V�[��(HVS%c%c, %d, %d)]\n", c[1], c[2], Dig(c[3], c[4]), Dig(c[5], c[6]));
				c += 7;
				break;

			case 'M': //BGM �֘A
				c1  = c[1];
				c  += 2;

				if(c1 == 'f')
				{
					TRACEOUT("[BGM �t�F�[�h�A�E�g]\n");
					ScriptMusicFadeOut();
				}
				else if (c1 == 'n')
				{
					c2 = *c++;
					c3 = *c++;
					TRACEOUT("[BGM �Đ�(next): M_%c%c\n", c2, c3);
					ScriptMusicStart(SizukuGetBgmNo(Dig(c2, c3)), TRUE);
				}
				else if (c1 == 'w')
				{
					TRACEOUT("[BGM FADE WAIT]\n");
				}
				else if (c1 >= '0' && c1 <= '2')
				{
					c2 = *c++;
					TRACEOUT("[BGM �Đ�: M_%c%c]\n", c1, c2);
					ScriptMusicStart(SizukuGetBgmNo(Dig(c1, c2)), TRUE);
				}
				else if (c1 == 's')
				{
					TRACEOUT("[BGM ��~]\n");
					ScriptMusicStop();
				}
				else
				{
					TRACEOUT("[cmd:4d][cmd:%x]\n", c1);
				}
				break;

			case 'P': //PCM �֘A
				c1  = c[1];
				c  += 2;

				if(c1 == 'l')
				{
					c2 = *c++;
					c3 = *c++;
					TRACEOUT("[PCM���[�h(%c%c)]\n", c2, c3);

				}
				else if (c1 >= '0' && c1 <= '9')
				{
					c2 = *c++;
					c3 = *c++;
					c4 = *c++;
					TRACEOUT("[PCM�Đ��w��(%c%c, %c%c)\n]", c1, c2, c3, c4);

				}
				else if(c1 == 'f')
				{
					TRACEOUT("[PCM�t�F�[�h�A�E�g?]\n");
				}
				else if(c1 == 'w')
				{
					TRACEOUT("[PCM wait?]\n");
				}
				else if(c1 == 's')
				{
					TRACEOUT("[PCM��~]\n");
				}
				else
				{
					TRACEOUT("[cmd:50][cmd:%x]\n");
				}
				break;

			case 'X':
				TRACEOUT("[�\\���I�t�Z�b�g�w��: %x]\n", c[1]);
				c += 2;
				break;

			case 's':
				TRACEOUT("[�\\�����x�w��?: %x]\n", c[1]);
				c += 2;
				break;

			default:
				TRACEOUT("[ScriptParserTxt unknown = %02x][no: %02x]\n", c[0], s->scnNo);
				for(;;){}
				break;
		} // switch(c[0])
	} // for(;;)
}
#undef c

//---------------------------------------------------------------------------
EWRAM_CODE void ScriptWaitPage()
{
	ScreenCursorMoveIn();
	ScriptKey();

	ScreenFontNewLineTxt();
	ScreenCursorMoveOut();
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptWaitKey()
{
	ScreenCursorMoveIn();
	ScriptKey();

	ScreenCursorMoveOut();
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptKey()
{
Restart:

	KeyWait(KEY_A | KEY_DOWN | KEY_LEFT | KEY_R);
	u16 now = KeyGetNow();

	if(now & KEY_R)
	{
		return;
	}
	else if(now & KEY_LEFT)
	{
		if( HistoryIsEmpty() == FALSE )
		{
			HistoryReferebce();
		}

		goto Restart;
	}

	while( KeyGet2() != KEY_NONE )
	{
		//EMPTY
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE u8* ScriptDrawCode(u8* p)
{
	u16 buf[200], txt[200];
	u16 i = 0, len;
	u8* c = p;

	do
	{
		if(c[0] == 'r')
		{
			//���s�͖������܂�
			c++;
			continue;
		}

		buf[i++] = ((c[0] & 0x7f) << 8) + c[1];
		c += 2;

	} while(c[0] & 0x80 || c[0] == 'r');

	//�֑������̏��������܂�
	len = ScreenFontSetHyphenation(buf, txt, i);

	//1��ʈȓ��ɏ������߂邩�`�F�b�N�����܂�
	if( ScreenFontIsCnt(len) == TRUE )
	{
		ScreenFontDrawCls();
		len = ScreenFontSetHyphenation(buf, txt, i);

		HistoryAdd(p);
	}

	ScreenFontDrawStr(txt, len);
	return c;
}
//---------------------------------------------------------------------------
EWRAM_CODE u8* ScriptWaitSelect(u8* c)
{
	ScreenFontDrawCls();

	ScriptParserTxt(c[1], TRUE);
	ScreenFontNewLineTxt();

	//�s����3�����ȏ�̏ꍇ�́A��ʂ��������܂�
	if( ScreenFontGetY() >= 3 )
	{
		ScreenFontDrawCls();
	}

	u16 key;
	s16 sel = -1;
	u16 x   = ScreenFontGetX();
	u16 y   = ScreenFontGetY();

	ScriptDrawSelect(c, sel);

	for(;;)
	{
		WaitForVsync();
		key = KeyGet();

		if(key == KEY_NONE)
		{
			continue;
		}
		else if( (key != KEY_DOWN) && sel == -1 )
		{
			//�ԈႦ�ă{�^���������̂�h�~���܂�
			continue;
		}

		if(key & KEY_A)
		{
			break;
		}
		else if(key & KEY_UP)
		{
			if(sel == 0) continue;
			sel--;

			ScreenFontSetXY(x, y);
			ScriptDrawSelect(c, sel);
		}
		else if(key & KEY_DOWN)
		{
			if(sel+1 >= c[2]) continue;
			sel++;

			ScreenFontSetXY(x, y);
			ScriptDrawSelect(c, sel);
		}
	}

	ScreenFontDrawCls();
	HistoryAdd( Script.pTxt + GET_SHORT(Script.pTxt + (c[3+sel*2] + 1) * 2) );

	TRACEOUT("�I�𕪊�: %d (+%02x)\n", sel, c[4 + sel*2]);
	return c = c + 3 + c[2]*2 + c[4 + sel*2];
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptDrawSelect(u8* c, s8 sel)
{
	s8 i;
	for(i=0; i<c[2]; i++)
	{
		if(i == sel)
		{
			FontLeafSetAttr(FONT_LEAF_COLOR_WHITE);
		}
		else
		{
			FontLeafSetAttr(FONT_LEAF_COLOR_GRAY);
		}

		TRACEOUT("[�I����: %d][���b�Z�[�W: %d][�I�t�Z�b�g: %02x]\n", i, c[3+i*2], c[4+i*2]);
		ScriptParserTxt(c[3+i*2], FALSE);
		ScreenFontNewLineTxt();
	}

	FontLeafSetAttr(FONT_LEAF_COLOR_WHITE);
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptMusicStart(u8 no, bool isLoop)
{
	char buf[64];
	_Sprintf(buf, SIZUKU_SND_STR, no);

	u8* pSnd = GBFSGetFilePointer(buf);

	if(pSnd == NULL)
	{
		//�t�@�C�����Ȃ��Ă��x��͂Ȃ��̂ŁA�G���[�ɂ��Ă��Ȃ��ł�
		TRACEOUT("[BGM not found: %s]\n", buf);
		return;
	}

	AdStart(pSnd, GBFSGetFileLength(), isLoop);
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptMusicStop()
{
	AdStop();
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptMusicFadeOut()
{
	//TODO FadeOut����
	ScriptMusicStop();
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptDebugScn(u16 no)
{
	char buf[64];
	_Sprintf(buf, "scn = %03d", no);

	Mode3DrawFillBox(0, 0, 8*9, 11, COLOR_BLACK);
	Mode3DrawFontStr(0, 0, (u8*)buf, COLOR_WHITE);
	ScreenImgUpdate();
}
//---------------------------------------------------------------------------
EWRAM_CODE void ScriptDebugTxt(u8 no)
{
	char buf[64];
	_Sprintf(buf, "txt = %03d", no);

	Mode3DrawFillBox(8*9, 0, 8*9+7*9, 11, COLOR_BLACK);
	Mode3DrawFontStr(8*9, 0, (u8*)buf, COLOR_WHITE);
	ScreenImgUpdate();
}






//---------------------------------------------------------------------------
EWRAM_CODE void HistoryInit()
{
	History.cnt = 0;
}
//---------------------------------------------------------------------------
EWRAM_CODE void HistoryAdd(u8* pTxtCur)
{
	ST_HISTORY* p = &History;

	u16 i = p->cnt;
	while(i >= 1)
	{
		p->pTxtCur[i] = p->pTxtCur[i-1];
		i--;
	}

	TRACEOUT("[History Add]\n");
	p->pTxtCur[0] = pTxtCur;


	if(p->cnt+1 < HISTORY_CNT)
	{
		p->cnt++;
	}
}
//---------------------------------------------------------------------------
EWRAM_CODE bool HistoryIsEmpty()
{
	return History.cnt <= 1 ? TRUE : FALSE;
}
//---------------------------------------------------------------------------
EWRAM_CODE void HistoryReferebce()
{
	ST_HISTORY* p = &History;

	u16 key;
	u16 x      = ScreenFontGetX();
	u16 y      = ScreenFontGetY();
	u8  selMax = p->cnt;
	u8  sel    = 1;

	ScreenCursorMoveOut();
	ScreenFontDrawClsOAM();
	ScreenFontClearXY();

	FontLeafSetAttr(FONT_LEAF_COLOR_GRAY);
	HistoryParserTxt(p->pTxtCur[sel]);

	for(;;)
	{
		WaitForVsync();
		key = KeyGet();

		if(key == KEY_NONE)
		{
			continue;
		}

		if(key & KEY_B)
		{
			break;
		}
		else if(key & KEY_LEFT)
		{
			if(sel+1 >= selMax) continue;
			sel++;

			ScreenFontDrawClsOAM();
			ScreenFontClearXY();
			HistoryParserTxt(p->pTxtCur[sel]);
		}
		else if(key & KEY_RIGHT)
		{
			if(sel == 1) break;
			sel--;

			ScreenFontDrawClsOAM();
			ScreenFontClearXY();
			HistoryParserTxt(p->pTxtCur[sel]);
		}
	}

	//��ʂ𕜋A�����܂�
	FontLeafSetAttr(FONT_LEAF_COLOR_WHITE);
	ScreenFontDrawRestore();
	ScreenFontSetXY(x, y);

	ScreenCursorMoveIn();
}
//---------------------------------------------------------------------------
//�u���v�e�L�X�g�p�[�T�{��(����\���p)
EWRAM_CODE void HistoryParserTxt(u8* c)
{
	u8  c1;
	u16 buf[200], txt[200];
	u16 i, len;

	for(;;)
	{
		if(c[0] & 0x80 || c[0] == 'r')
		{
			i = 0;

			do
			{
				if(c[0] == 'r')
				{
					c++;
					continue;
				}

				buf[i++] = ((c[0] & 0x7f) << 8) + c[1];
				c += 2;

			} while(c[0] & 0x80 || c[0] == 'r');

			//�֑���������
			len = ScreenFontSetHyphenation(buf, txt, i);

			if( ScreenFontIsCnt(len) == TRUE )
			{
				return;
			}

			ScreenFontDrawStrNoBuf(txt, len);
			continue;
		}

		switch(c[0])
		{
			case '$':
				c++;
				return;

			case 'p':
			case 'k':
			case 'K':
			case '0':
			case 'Q':
			case 'F':
				c++;
				break;

			case 'C':
			case 'D':
				c += 4;
				break;

			case 'B':
			case 'E':
			case 'V':
			case 'H':
				c += 7;
				break;

			case 'S':
			case 'A':
			case 'a':
				c += 10;
				break;

			case 'M':
				c1  = c[1];
				c  += 2;

				if(c1 == 'f' || c1 == 'w' || c1 == 's')
				{
					//EMPTY
				}
				else if (c1 == 'n')
				{
					c += 2;
				}
				else if (c1 >= '0' && c1 <= '2')
				{
					c++;
				}
				else
				{
					//EMPTY
				}
				break;

			case 'P': //PCM �֘A
				c1  = c[1];
				c  += 2;

				if(c1 == 'l')
				{
					c += 2;
				}
				else if (c1 >= '0' && c1 <= '9')
				{
					c += 3;
				}
				else if(c1 == 'f' || c1 == 'w' || c1 == 's')
				{
					//EMPTY
				}
				else
				{
					//EMPTY
				}
				break;

			case 'X':
			case 's':
				c += 2;
				break;

			default:
				TRACEOUT("[HistoryParserTxt unknown = %02x][no: %02x]\n", c[0]);
				for(;;){}
				break;

		} // switch(c[0])
	} // for(;;)
}
